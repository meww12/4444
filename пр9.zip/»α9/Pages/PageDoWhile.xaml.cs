﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace жееееесть.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageDoWhile.xaml
    /// </summary>
    public partial class PageDoWhile : Page
    {
        public PageDoWhile()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            Class1.frmObject.Navigate(new PageWhile());
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            Class1.frmObject.Navigate(new PageFor());
        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            double X0 = Convert.ToDouble(txtx0.Text);
            double Xk = Convert.ToDouble(txtXk.Text);
            double Dx = Convert.ToDouble(txtDx.Text);
            double a = Convert.ToDouble(txtA.Text);
            double b = Convert.ToDouble(txtB.Text);
            
            double x = X0;

            do
            {
                double y = Math.Pow(10, -1) * a * Math.Pow(x, 3) * Math.Tan(a - b * x);
                lstTable.Items.Add($"x = {x} y = {y}");
                x += Dx;
            }
            while (x <= (Xk + Dx / 2));
            
        }
    }
}
