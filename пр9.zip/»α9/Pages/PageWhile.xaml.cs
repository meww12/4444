﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace жееееесть.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageWhile.xaml
    /// </summary>
    public partial class PageWhile : Page
    {
        public PageWhile()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, RoutedEventArgs e)
        {
            double X0 = Convert.ToDouble(txtx0.Text);
            double Xk = Convert.ToDouble(txtXk.Text);
            double Dx = Convert.ToDouble(txtDx.Text);
            double b = Convert.ToDouble(txtb.Text);
            double a = Convert.ToDouble(txtA.Text);

            double x = X0;
            while(x<=Xk)
            {
                double y = Math.Pow(10, -1) * a * Math.Pow(x, 3) * Math.Tan(a - b * x);
                lstTable.Items.Add($"x = {x} y = {y}");
                x += Dx;
            }
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {

        }

        private void lstTable_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
